+++
date = "2016-08-15T16:11:58+05:30"
title = "MongoDB C++ Driver Manual"
type = "index"
+++

# MongoDB C++ Driver

This is the legacy site for the MongoDB C++ Driver documentation. See the new
[MongoDB C++ Driver
documentation](https://www.mongodb.com/docs/languages/cpp/).

For documentation of the legacy C++ driver (versions older than 3.0), see the
[Legacy C++ Driver documentation](https://mongocxx.org/legacy-v1/).
